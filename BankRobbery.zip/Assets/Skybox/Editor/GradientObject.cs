﻿using UnityEngine;

namespace GradientSkybox
{
    public class GradientObject : ScriptableObject
    {
        public Gradient gradient = new Gradient();
    }
}
